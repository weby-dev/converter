# 1. Install Requirements
`pip install -r requirements.txt`

# 2. Fill your telegram token where is:
`TOKEN="YOUR TELEGRAM TOKEN HERE"`

# 2. Run
`python main.py`
